# Implement the PageRank Algorithm to Rank Web Pages based on Link Analysis.

import numpy as np
n=int(input("Enter number of nodes (web pages): "))
nodes=[]
for i in range(n):
    nodes.append(chr(65+i))
print("\nNodes:",nodes)
edges=int(input("\nEnter number of links: "))
links=[]
print("\nEnter links (From Node To Node)")
print("Example: A B means A points to B")
for i in range(edges):
    a,b=input(f"Link {i+1}: ").split()
    links.append((a,b))
iterations=int(input("\nEnter number of iterations: "))
M=np.zeros((n,n))
for start,end in links:
    start_index=nodes.index(start)
    end_index=nodes.index(end)
    count=0
    for x,y in links:
        if x==start:
            count+=1
    M[end_index][start_index]=1/count
print("Transition Matrix (M)")
print(M)
r=np.ones((n,1))/n
print("Initial Vector r0")
print(r)
for i in range(iterations):
    r=np.dot(M,r)
    print("Iteration",i+1)
    print("Rank Vector r",i+1)
    print(r)
print("Final PageRank of Web Pages")
for i in range(n):
    print(nodes[i],"=",round(float(r[i][0]),4))
max_index=np.argmax(r)
print("Highest PageRank Node")
print(nodes[max_index],"has highest PageRank value =",round(float(r[max_index][0]),4))
print("Ranking Order")
ranking=[]
for i in range(n):
    ranking.append((nodes[i],float(r[i][0])))
ranking.sort(key=lambda x:x[1],reverse=True)
rank=1
for node,value in ranking:
    print(rank,".",node,"->",round(value,4))
    rank+=1

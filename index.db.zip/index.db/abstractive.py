# Implement the Text Summarization Algorithm (Abstractive)

from transformers import pipeline

text = """
Information Retrieval is the process of obtaining relevant information
from a large collection of information resources. Search engines use
Information Retrieval techniques to find useful documents for users.
Text summarization is an important application of Information Retrieval
and Natural Language Processing. It helps users understand large
documents quickly by generating a shorter version of the original text.
Extractive summarization selects the most important sentences from the
original document without changing their wording.
"""

summarizer = pipeline("summarization", model="t5-small")

result = summarizer(
    "summarize: " + text,
    max_length=50,
    min_length=20,
    do_sample=False
)

print("Original Text:")
print(text)

print("\nAbstractive Summary:")
print(result[0]["summary_text"])

#py --version

#py -m pip install transformers==4.41.2 torch sentencepiece

#py -c "import transformers; print(transformers.__version__)"

#py -c "import torch; print(torch.__version__)"

#py -m idlelib

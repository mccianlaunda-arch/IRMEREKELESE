# Implement the Vector Space Model with TF-IDF Weighting and Cosine Similarity.

import math
doc1=input("Enter Document 1: ")
doc2=input("Enter Document 2: ")
doc3=input("Enter Document 3: ")
query=input("Enter Query: ")
docs=[doc1,doc2,doc3]
print("\n--- FREQUENCY TABLE ---")
freq_table=[]
for i,doc in enumerate(docs,start=1):
    words=doc.lower().split()
    freq={}
    for w in words:
        freq[w]=freq.get(w,0)+1
    freq_table.append(freq)
    print(f"\nDocument {i}: {freq}")
vocab=set()
for doc in docs:
    for word in doc.lower().split():
        vocab.add(word)
for word in query.lower().split():
    vocab.add(word)
vocab_sorted=sorted(vocab)
print("\n--- VOCABULARY ---")
print(vocab_sorted)
def create_vector(text):
    words=text.lower().split()
    return [words.count(word) for word in vocab_sorted]
doc_vectors=[create_vector(doc) for doc in docs]
query_vector=create_vector(query)
print("\n--- VECTORS ---")
for i,vec in enumerate(doc_vectors,start=1):
    print(f"Document {i} Vector: {vec}")
print("Query Vector:",query_vector)
def cosine_similarity(v1,v2):
    dot=0
    mag1=0
    mag2=0
    for i in range(len(v1)):
        dot+=v1[i]*v2[i]
        mag1+=v1[i]**2
        mag2+=v2[i]**2
    if mag1==0 or mag2==0:
        return 0
    return dot/(math.sqrt(mag1)*math.sqrt(mag2))
print("\n--- COSINE SIMILARITY ---")
scores=[]
for i in range(len(doc_vectors)):
    score=cosine_similarity(query_vector,doc_vectors[i])
    scores.append((i+1,score))
    print(f"Document {i+1}: {score:.4f}")
scores.sort(key=lambda x:x[1],reverse=True)
print("\n--- RANKED DOCUMENTS ---")
for rank,(doc_id,score) in enumerate(scores,start=1):
    print(f"Rank {rank}: Document {doc_id} (Score: {score:.4f})")

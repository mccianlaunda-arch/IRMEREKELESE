# Develop a Spelling Correction Module using Edit Distance Algorithm.

str1=input("Enter the First String: ")
str2=input("Enter the Second String: ")
rows=len(str1)+1
cols=len(str2)+1
matrix=[[0 for j in range(cols)] for i in range(rows)]
for i in range(rows):
    matrix[i][0]=i
for j in range(cols):
    matrix[0][j]=j
for i in range(1,rows):
    for j in range(1,cols):
        if str1[i-1]==str2[j-1]:
            matrix[i][j]=matrix[i-1][j-1]
        else:
            matrix[i][j]=min(
                matrix[i-1][j],
                matrix[i][j-1],
                matrix[i-1][j-1]
            )+1
print("\nEdit Distance Matrix:\n")
for row in matrix:
    for value in row:
        print(value,end="\t")
    print()
print("\nFinal Edit Distance =",matrix[rows-1][cols-1])

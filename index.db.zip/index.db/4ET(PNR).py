# Use an evaluation toolkit to measure average precision and other evaluation metrics.

from sklearn.metrics import precision_score,recall_score,f1_score
from sklearn.metrics import average_precision_score
actual=[1,1,0,1,0]
predicted=[1,1,1,0,0]
print("Actual Values:")
print(actual)
print("\nPredicted Values:")
print(predicted)
true_positive=0
true_negative=0
false_positive=0
false_negative=0
for i in range(len(actual)):
    if actual[i]==1 and predicted[i]==1:
        true_positive=true_positive+1
    elif actual[i]==0 and predicted[i]==0:
        true_negative=true_negative+1
    elif actual[i]==0 and predicted[i]==1:
        false_positive=false_positive+1
    elif actual[i]==1 and predicted[i]==0:
        false_negative=false_negative+1
print("\nTrue Positive:",true_positive)
print("True Negative:",true_negative)
print("False Positive:",false_positive)
print("False Negative:",false_negative)
precision=precision_score(actual,predicted)
recall=recall_score(actual,predicted)
f_measure=f1_score(actual,predicted)
average_precision=average_precision_score(actual,predicted)
print("\nEvaluation Results:")
print("\nPrecision:")
print("Precision =",round(precision,2))
print("\nRecall:")
print("Recall =",round(recall,2))
print("\nF-Measure:")
print("F-Measure =",round(f_measure,2))
print("\nAverage Precision:")
print("Average Precision =",round(average_precision,2))
print("\nFinal Results:")
print("Precision:",round(precision,2))
print("Recall:",round(recall,2))
print("F-Measure:",round(f_measure,2))
print("Average Precision:",round(average_precision,2))

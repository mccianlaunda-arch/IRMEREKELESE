# Build a Question-Answering System Using Technique Such as Information Extraction.

text="""
India is a country in South Asia.
The capital of India is New Delhi.
The Prime Minister of India is Narendra Modi.
India gained independence on 15 August 1947.
The national animal of India is the Bengal Tiger.
The national sport of India is hockey.
"""
# Information Extraction
information={
    "capital":"New Delhi",
    "prime minister":"Narendra Modi",
    "independence":"15 August 1947",
    "national animal":"Bengal Tiger",
    "national sport":"Hockey"
}
def answer_question(question):
    question=question.lower()
    if "capital" in question:
        return information["capital"]
    elif "prime minister" in question:
        return information["prime minister"]
    elif "independence" in question:
        return information["independence"]
    elif "national animal" in question:
        return information["national animal"]
    elif "national sport" in question:
        return information["national sport"]
    else:
        return "Sorry, I don't know the answer."
print("Knowledge Base:")
print(text)
while True:
    question=input("\nEnter your question (type 'exit' to stop): ")
    if question.lower()=="exit":
        break
    answer=answer_question(question)
    print("Answer:",answer)

from sklearn.svm import SVC
from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score
# Implement a learning to rank algorithm using RankSVM.
X=[[1,0],[2,1],[3,2],[4,3],[5,4],[2,0],[3,1],[4,2],[5,3],[1,1]]
y=[0,0,1,1,1,0,1,1,1,0]
print("Training Data:")
print(X)
print("\nTraining Labels:")
print(y)
model=SVC(kernel='linear')
# Train the ranking model using labelled data.
print("\nCreating Linear SVM Model...")
model.fit(X,y)
print("Model Training Completed.")
test_data=[[1,0],[2,1],[3,2],[4,3],[5,4]]
actual=[0,0,1,1,1]
print("\nTest Data:")
print(test_data)
print("\nActual Test Labels:")
print(actual)
predicted=model.predict(test_data)
scores=model.decision_function(test_data)
print("\nPredicted Labels:")
print(predicted)
print("\nDecision Scores:")
for i in range(len(test_data)):
    print("Test Point",i+1,":",test_data[i],"Score:",round(scores[i],4))
# Evaluate the effectiveness of the ranking model.
accuracy=accuracy_score(actual,predicted)
precision=precision_score(actual,predicted)
recall=recall_score(actual,predicted)
f_measure=f1_score(actual,predicted)
print("\nLearning to Rank using RankSVM")
print("Ranking Results:")
for i in range(len(test_data)):
    print("Point",i+1,"-> Rank:",predicted[i],"Score:",round(scores[i],4))
print("\nTraining and Evaluation")
print("Accuracy:")
print(round(accuracy,2))
print("\nPrecision:")
print(round(precision,2))
print("\nRecall:")
print(round(recall,2))
print("\nF-Measure:")
print(round(f_measure,2))
print("\nFinal Results:")
print("Accuracy =",round(accuracy,2))
print("Precision =",round(precision,2))
print("Recall =",round(recall,2))
print("F-Measure =",round(f_measure,2))

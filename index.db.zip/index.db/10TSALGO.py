# Implement the Text Summarization Algorithm (Extractive or Abstractive).

import nltk
import heapq
from nltk.corpus import stopwords
from nltk.tokenize import sent_tokenize,word_tokenize
text="""
Information Retrieval is the process of obtaining relevant information
from a large collection of information resources. Search engines use
Information Retrieval techniques to find useful documents for users.
Text summarization is an important application of Information Retrieval
and Natural Language Processing. It helps users understand large
documents quickly by generating a shorter version of the original text.
Extractive summarization selects the most important sentences from the
original document without changing their wording.
"""
sentences=sent_tokenize(text)
stop_words=set(stopwords.words('english'))
word_frequency={}
for word in word_tokenize(text.lower()):
    if word.isalnum() and word not in stop_words:
        if word not in word_frequency:
            word_frequency[word]=1
        else:
            word_frequency[word]+=1
maximum_frequency=max(word_frequency.values())
for word in word_frequency:
    word_frequency[word]=word_frequency[word]/maximum_frequency
sentence_scores={}
for sentence in sentences:
    for word in word_tokenize(sentence.lower()):
        if word in word_frequency:
            if len(sentence.split())<40:
                if sentence not in sentence_scores:
                    sentence_scores[sentence]=word_frequency[word]
                else:
                    sentence_scores[sentence]+=word_frequency[word]
summary_sentences=heapq.nlargest(3,sentence_scores,key=sentence_scores.get)
summary=" ".join(summary_sentences)
print("Original Text:")
print(text)
print("\nExtractive Summary:")
print(summary)

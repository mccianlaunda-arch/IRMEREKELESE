# Implement the Boolean Retrieval Model and process queries.

n=int(input("Enter number of documents: "))
documents=[]
for i in range(n):
    documents.append(input(f"Enter Document {i+1}: "))
print("\nDocuments:")
for i in range(n):
    print("D",i+1,":",documents[i])
query=input("\nEnter Boolean Query: ").lower()
words=query.split()
terms=[]
for doc in documents:
    for word in doc.lower().split():
        if word not in terms:
            terms.append(word)
print("\nTerms:")
print(terms)
print("\nTerm Document Matrix:")
print("Term",end="\t")
for i in range(n):
    print("D"+str(i+1),end="\t")
print()
for term in terms:
    print(term,end="\t")
    for doc in documents:
        if term in doc.lower().split():
            print(1,end="\t")
        else:
            print(0,end="\t")
    print()
term1=words[0]
operator=words[1]
term2=words[2]
result=[]
for i in range(n):
    doc=documents[i].lower().split()
    if operator=="and":
        if term1 in doc and term2 in doc:
            result.append(i)
    elif operator=="or":
        if term1 in doc or term2 in doc:
            result.append(i)
    elif operator=="not":
        if term1 in doc and term2 not in doc:
            result.append(i)
print("\nBoolean Query:",query)
print("\nRetrieved Documents:")
if len(result)==0:
    print("No documents found.")
else:
    for i in result:
        print("D",i+1,":",documents[i])

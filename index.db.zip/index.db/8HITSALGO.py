# Apply the HITS Algorithm to a Small Web Graph and Analyze the results.

import networkx as nx
import matplotlib.pyplot as plt
import math
n=int(input("Enter number of nodes: "))
nodes=[]
print("Enter node names:")
for i in range(n):
    nodes.append(input())
graph={}
for node in nodes:
    graph[node]=[]
e=int(input("Enter number of links(edges): "))
print("Enter links (From To):")
for i in range(e):
    u,v=input().split()
    graph[u].append(v)
iterations=int(input("Enter number of iterations: "))
G=nx.DiGraph()
for node in nodes:
    G.add_node(node)
for u in graph:
    for v in graph[u]:
        G.add_edge(u,v)
print("\nAccepted Graph")
print(graph)
plt.figure(figsize=(6,6))
pos=nx.spring_layout(G,seed=20)
nx.draw(G,pos,with_labels=True,node_size=2000,node_color="skyblue",arrows=True,font_size=12,font_weight="bold")
plt.title("Web Graph")
plt.show()
authority={}
hub={}
for node in nodes:
    authority[node]=1.0
    hub[node]=1.0
for itr in range(iterations):
    print("Iteration",itr+1)
    new_authority={}
    for node in nodes:
        score=0
        for src in nodes:
            if node in graph[src]:
                score+=hub[src]
        new_authority[node]=score
    norm=math.sqrt(sum(value**2 for value in new_authority.values()))
    norm_authority={}
    for node in nodes:
        if norm!=0:
            norm_authority[node]=new_authority[node]/norm
        else:
            norm_authority[node]=0
    authority=norm_authority.copy()
    new_hub={}
    for node in nodes:
        score=0
        for dest in graph[node]:
            score+=authority[dest]
        new_hub[node]=score
    norm=math.sqrt(sum(value**2 for value in new_hub.values()))
    norm_hub={}
    for node in nodes:
        if norm!=0:
            norm_hub[node]=new_hub[node]/norm
        else:
            norm_hub[node]=0
    hub=norm_hub.copy()
print("\nAuthority Score")
for node in nodes:
    print(node,":",round(new_authority[node],4))
print("\nNormalized Authority Score")
for node in nodes:
    print(node,":",round(authority[node],4))
print("\nHub Score")
for node in nodes:
    print(node,":",round(new_hub[node],4))
print("\nNormalized Hub Score")
for node in nodes:
    print(node,":",round(hub[node],4))
best_authority=max(authority,key=authority.get)
best_hub=max(hub,key=hub.get)
print("FINAL RESULT")
print("Best Authority Node:",best_authority)
print("Authority Score:",round(authority[best_authority],4))
print("Best Hub Node:",best_hub)
print("Hub Score:",round(hub[best_hub],4))

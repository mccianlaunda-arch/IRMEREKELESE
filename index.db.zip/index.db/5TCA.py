# Implement a text classification algorithm.

n=int(input("Enter number of training records: "))
data=[]
print("\nEnter training data:")
for i in range(n):
    print(f"\nRecord {i+1}")
    fever=input("Fever (Yes/No): ").strip().lower()
    cough=input("Cough (Yes/No): ").strip().lower()
    body_pain=input("Body Pain (Yes/No): ").strip().lower()
    covid=input("Covid (Yes/No): ").strip().lower()
    data.append({
        "fever":fever,
        "cough":cough,
        "body_pain":body_pain,
        "covid":covid
    })
print("\nEnter symptoms of the patient to classify:")
test_fever=input("Fever (Yes/No): ").strip().lower()
test_cough=input("Cough (Yes/No): ").strip().lower()
test_body_pain=input("Body Pain (Yes/No): ").strip().lower()
classes=["yes","no"]
probabilities={}
for covid_class in classes:
    class_records=[row for row in data if row["covid"]==covid_class]
    prior=len(class_records)/len(data)
    probability=prior
    count=sum(row["fever"]==test_fever for row in class_records)
    probability*=count/len(class_records)
    count=sum(row["cough"]==test_cough for row in class_records)
    probability*=count/len(class_records)
    count=sum(row["body_pain"]==test_body_pain for row in class_records)
    probability*=count/len(class_records)
    probabilities[covid_class]=probability
print("\nNaive Bayes Classification")
print("P(Covid = Yes) =",probabilities["yes"])
print("P(Covid = No) =",probabilities["no"])
if probabilities["yes"]>probabilities["no"]:
    print("\nPrediction: COVID = YES")
else:
    print("\nPrediction: COVID = NO")

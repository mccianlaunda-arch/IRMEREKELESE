# Implement an inverted index construction algorithm using posting method.

import collections
print("--- STEP 1: Accept documents ---")
num_docs=int(input("Enter number of documents: "))
documents={}
for i in range(num_docs):
    doc_id=i+1
    documents[doc_id]=input(f"Enter content for Document {doc_id}: ")
pairs=[]
for doc_id,text in documents.items():
    for word in text.lower().split():
        word=word.strip(".,!?;:()\"'")
        if word:
            pairs.append((word,doc_id))
print("\n--- STEP 2: Term and Doc_ID ---")
print("Term           | Doc_ID")
print("-"*25)
for term,doc_id in pairs:
    print(f"{term:<15}| {doc_id}")
sorted_pairs=sorted(pairs)
print("\n--- STEP 3: Arranged table ---")
print("Term           | Doc_ID")
print("-"*25)
for term,doc_id in sorted_pairs:
    print(f"{term:<15}| {doc_id}")
term_docs=collections.defaultdict(set)
for term,doc_id in sorted_pairs:
    term_docs[term].add(doc_id)
print("\n--- STEP 4: Term and Doc_Freq ---")
print("Term           | Doc_Freq")
print("-"*25)
for term in sorted(term_docs):
    print(f"{term:<15}| {len(term_docs[term])}")
print("\n--- STEP 5: Posting Lists ---")
print("Term           | Posting List")
print("-"*35)
for term in sorted(term_docs):
    posting=" -> ".join(map(str,sorted(term_docs[term])))
    print(f"{term:<15}| {posting}")

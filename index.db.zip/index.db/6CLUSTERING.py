# Clustering for Information Retrieval.

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.metrics.pairwise import euclidean_distances
X=[
    "India won the cricket match",
    "The player scored a century",
    "The football team won the game",
    "The batsman played very well",
    "The smartphone has a powerful processor",
    "The laptop has excellent performance",
    "The phone camera has high resolution",
    "The computer has a fast processor"
]
y=[0,0,0,0,1,1,1,1]
n_clusters=int(input("Enter number of clusters: "))
print("\nX:")
for i,x in enumerate(X):
    print(f"Point {i+1}: {x}")
print("\ny:",y)
print("Number of clusters:",n_clusters)
tfidf=TfidfVectorizer()
X_vector=tfidf.fit_transform(X)
kmeans=KMeans(n_clusters=n_clusters,random_state=42,n_init=10)
kmeans.fit(X_vector)
cluster_labels=kmeans.labels_
centroids=kmeans.cluster_centers_
print("\nCentroids:")
for i,centroid in enumerate(centroids):
    print(f"Centroid K{i+1}:")
    print(centroid)
distances=euclidean_distances(centroids)
print("\nDistance between clusters:")
for i in range(n_clusters):
    for j in range(i+1,n_clusters):
        print(f"Distance between K{i+1} and K{j+1}: {distances[i][j]:.4f}")
print("\nCluster assignment:")
for i,x in enumerate(X):
    print(f"Point {i+1}: {x}")
    print(f"Cluster: K{cluster_labels[i]+1}")
new_document=input("\nEnter new document: ")
new_vector=tfidf.transform([new_document])
new_cluster=kmeans.predict(new_vector)
print(f"\nNew document: {new_document}")
print(f"Assigned cluster: K{new_cluster[0]+1}")
print("\nFinal:")
for cluster in range(n_clusters):
    print(f"\nCluster K{cluster+1} has these points:")
    for i,x in enumerate(X):
        if cluster_labels[i]==cluster:
            print("-",x)
print("\nProcess Completed Successfully!")

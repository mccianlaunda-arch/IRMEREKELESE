# Develop a web crawler to fetch and index web pages and handle challenges such as robots.txt, dynamic content, and crawling delays.

import requests
from bs4 import BeautifulSoup
import time
from urllib.robotparser import RobotFileParser
url="https://example.com"
try:
    robots=RobotFileParser()
    robots.set_url(url+"/robots.txt")
    robots.read()
    if robots.can_fetch("*",url):
        time.sleep(2)
        page=requests.get(url)
        soup=BeautifulSoup(page.text,"html.parser")
        print("Web Page Title:")
        print(soup.title.text)
        print("\nWeb Page Content:")
        print(soup.get_text()[:300])
        print("\nWeb Page Links:")
        for link in soup.find_all("a"):
            href=link.get("href")
            if href:
                print(href)
        print("\nCrawling completed.")
        print("Note: Dynamic content may require JavaScript.")
    else:
        print("Crawling is not allowed by robots.txt")
except:
    print("Error while fetching the web page")
